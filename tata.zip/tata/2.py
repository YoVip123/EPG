import cloudscraper
def get_headers():
    return {
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.9',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
        'Origin': 'https://watch.tataplay.com',
        'Pragma': 'no-cache',
        'Referer': 'https://watch.tataplay.com/',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'cross-site',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131.0.0.0 Safari/537.36',
        'content-type': 'application/json',
        'locale': 'ENG',
        'platform': 'web',
        'sec-ch-ua': '"Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"'
    }
scraper = cloudscraper.create_scraper()

url = "https://tm.tapi.videoready.tv/content-detail/pub/api/v2/channels/schedule?date=29-03-2026"

payload = {"id": 1301}

headers = get_headers()

r = scraper.post(url, headers=headers, json=payload)

print(r.status_code)
print(r.text[:500])